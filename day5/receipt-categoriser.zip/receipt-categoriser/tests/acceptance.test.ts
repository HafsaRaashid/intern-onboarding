// tests/acceptance.test.ts
// Acceptance tests for the Receipt Categoriser.
// Covers AC-01 (happy path), AC-03 (LLM fallback), AC-04 (OCR failure),
// AC-05 (oversized payload), and AC-07 (feature flag off).
// All external dependencies are mocked — no real Azure calls.

import {
  categoriseReceipt,
  CategoriserResult,
  CategoriserError,
  CategoriserInput,
  CategoriserDeps,
  OcrClient,
  LlmClient,
  FeatureFlagClient,
  TelemetryClient,
  ImageMetadataClient,
  ClaimRepository,
} from "../src/categoriser";

// ── Helper: check if response is an error ──

function isError(result: CategoriserResult | CategoriserError): result is CategoriserError {
  return "code" in result;
}

// ── Mock factories ──

function createMockDeps(overrides?: Partial<CategoriserDeps>): CategoriserDeps {
  const defaults: CategoriserDeps = {
    featureFlag: {
      isEnabled: async () => true,
    },
    ocr: {
      extractText: async () => "Generic receipt text",
    },
    llm: {
      classify: async () => ({ category: "Meals", confidence: 0.85 }),
    },
    telemetry: {
      trackEvent: () => {},
    },
    imageMetadata: {
      getImageSize: async () => 5 * 1024 * 1024, // 5 MB
      getImageFormat: async () => "jpeg",
    },
    claims: {
      exists: async () => true,
    },
  };

  return { ...defaults, ...overrides };
}

function createValidInput(): CategoriserInput {
  return {
    claim_id: "test-claim-001",
    receipt_image_url: "https://storage.blob.core.windows.net/receipts/receipt-001.jpeg",
  };
}

// ── Test runner ──

interface TestCase {
  name: string;
  fn: () => Promise<void>;
}

const tests: TestCase[] = [];

function describe(name: string, fn: () => void) {
  console.log(`\n  ${name}`);
  fn();
}

function it(name: string, fn: () => Promise<void>) {
  tests.push({ name, fn });
}

function assert(condition: boolean, message: string) {
  if (!condition) {
    throw new Error(`Assertion failed: ${message}`);
  }
}

// ── AC-01: Happy path — clear meal receipt ──

describe("AC-01: Happy path — clear meal receipt", () => {
  it("returns Meals category with confidence >= 0.6 and source llm", async () => {
    const deps = createMockDeps({
      ocr: {
        extractText: async () =>
          "Noodles & Company Restaurant Bill - Rice and Curry LKR 2,400",
      },
      llm: {
        classify: async () => ({ category: "Meals", confidence: 0.88 }),
      },
    });

    const result = await categoriseReceipt(createValidInput(), deps);

    assert(!isError(result), "Should not return an error");
    const r = result as CategoriserResult;
    assert(r.category === "Meals", `Expected category "Meals", got "${r.category}"`);
    assert(r.confidence >= 0.6, `Expected confidence >= 0.6, got ${r.confidence}`);
    assert(r.source === "llm", `Expected source "llm", got "${r.source}"`);
    assert(r.needs_review === false, `Expected needs_review false, got ${r.needs_review}`);
    assert(r.claim_id === "test-claim-001", `Expected claim_id "test-claim-001", got "${r.claim_id}"`);
  });

  it("emits Application Insights categoriser.suggested event", async () => {
    let emittedEvent: { name: string; properties: Record<string, any> } | null = null;

    const deps = createMockDeps({
      ocr: {
        extractText: async () => "Restaurant Bill LKR 2,400",
      },
      llm: {
        classify: async () => ({ category: "Meals", confidence: 0.88 }),
      },
      telemetry: {
        trackEvent: (name, properties) => {
          emittedEvent = { name, properties };
        },
      },
    });

    await categoriseReceipt(createValidInput(), deps);

    assert(emittedEvent !== null, "Should emit a telemetry event");
    assert(
      emittedEvent!.name === "categoriser.suggested",
      `Expected event name "categoriser.suggested", got "${emittedEvent!.name}"`
    );
    assert(
      "claim_id" in emittedEvent!.properties,
      "Event should contain claim_id property"
    );
    assert(
      "latency_ms" in emittedEvent!.properties,
      "Event should contain latency_ms property"
    );
  });
});

// ── AC-03: LLM unavailable — fallback to rule-based ──

describe("AC-03: LLM unavailable — fallback to rule-based", () => {
  it("returns source rule-based when LLM throws a 503", async () => {
    const deps = createMockDeps({
      ocr: {
        extractText: async () =>
          "Cinnamon Grand Hotel - Room Charge 2 Nights - LKR 45,000",
      },
      llm: {
        classify: async () => {
          throw new Error("503 Service Unavailable");
        },
      },
    });

    const result = await categoriseReceipt(createValidInput(), deps);

    assert(!isError(result), "Should not return an error — fallback should handle it");
    const r = result as CategoriserResult;
    assert(r.source === "rule-based", `Expected source "rule-based", got "${r.source}"`);
    assert(r.category === "Lodging", `Expected category "Lodging", got "${r.category}"`);
    assert(r.confidence > 0, `Expected confidence > 0, got ${r.confidence}`);
  });

  it("does not expose LLM failure to the user", async () => {
    const deps = createMockDeps({
      ocr: {
        extractText: async () => "Hotel booking confirmation - 3 nights stay",
      },
      llm: {
        classify: async () => {
          throw new Error("503 Service Unavailable");
        },
      },
    });

    const result = await categoriseReceipt(createValidInput(), deps);

    assert(!isError(result), "Should return a valid result, not an error");
    const r = result as CategoriserResult;
    assert(
      r.source === "rule-based",
      "Should indicate rule-based source but not expose error"
    );
  });
});

// ── AC-04: OCR failure ──

describe("AC-04: OCR failure — unreadable image", () => {
  it("returns Other with confidence 0.0 and source default", async () => {
    const deps = createMockDeps({
      ocr: {
        extractText: async () => {
          throw new Error("Document Intelligence: unable to extract text");
        },
      },
    });

    const result = await categoriseReceipt(createValidInput(), deps);

    assert(!isError(result), "Should not return an HTTP error — handled gracefully");
    const r = result as CategoriserResult;
    assert(r.category === "Other", `Expected category "Other", got "${r.category}"`);
    assert(r.confidence === 0.0, `Expected confidence 0.0, got ${r.confidence}`);
    assert(r.source === "default", `Expected source "default", got "${r.source}"`);
    assert(r.needs_review === true, `Expected needs_review true, got ${r.needs_review}`);
  });

  it("returns Other when OCR returns empty text", async () => {
    const deps = createMockDeps({
      ocr: {
        extractText: async () => "",
      },
    });

    const result = await categoriseReceipt(createValidInput(), deps);

    assert(!isError(result), "Should not return an HTTP error");
    const r = result as CategoriserResult;
    assert(r.category === "Other", `Expected category "Other", got "${r.category}"`);
    assert(r.source === "default", `Expected source "default", got "${r.source}"`);
  });
});

// ── AC-05: Oversized payload ──

describe("AC-05: Oversized payload", () => {
  it("returns 413 when image exceeds 10 MB", async () => {
    const deps = createMockDeps({
      imageMetadata: {
        getImageSize: async () => 15 * 1024 * 1024, // 15 MB
        getImageFormat: async () => "jpeg",
      },
    });

    const result = await categoriseReceipt(createValidInput(), deps);

    assert(isError(result), "Should return an error");
    const err = result as CategoriserError;
    assert(err.code === 413, `Expected code 413, got ${err.code}`);
    assert(err.error === "File too large", `Expected "File too large", got "${err.error}"`);
    assert(
      err.max_bytes === 10485760,
      `Expected max_bytes 10485760, got ${err.max_bytes}`
    );
  });

  it("does not call OCR or LLM when image is too large", async () => {
    let ocrCalled = false;
    let llmCalled = false;

    const deps = createMockDeps({
      imageMetadata: {
        getImageSize: async () => 15 * 1024 * 1024,
        getImageFormat: async () => "jpeg",
      },
      ocr: {
        extractText: async () => {
          ocrCalled = true;
          return "text";
        },
      },
      llm: {
        classify: async () => {
          llmCalled = true;
          return { category: "Meals" as const, confidence: 0.9 };
        },
      },
    });

    await categoriseReceipt(createValidInput(), deps);

    assert(!ocrCalled, "OCR should not be called for oversized images");
    assert(!llmCalled, "LLM should not be called for oversized images");
  });
});

// ── AC-07: Feature flag off ──

describe("AC-07: Feature flag off", () => {
  it("returns null when feature flag is off", async () => {
    const deps = createMockDeps({
      featureFlag: {
        isEnabled: async () => false,
      },
    });

    const result = await categoriseReceipt(createValidInput(), deps);

    assert(result === null, "Should return null when feature flag is off");
  });

  it("does not call OCR or LLM when feature flag is off", async () => {
    let ocrCalled = false;
    let llmCalled = false;

    const deps = createMockDeps({
      featureFlag: {
        isEnabled: async () => false,
      },
      ocr: {
        extractText: async () => {
          ocrCalled = true;
          return "text";
        },
      },
      llm: {
        classify: async () => {
          llmCalled = true;
          return { category: "Meals" as const, confidence: 0.9 };
        },
      },
    });

    await categoriseReceipt(createValidInput(), deps);

    assert(!ocrCalled, "OCR should not be called when feature flag is off");
    assert(!llmCalled, "LLM should not be called when feature flag is off");
  });
});

// ── Run all tests ──

async function runTests() {
  let passed = 0;
  let failed = 0;

  for (const test of tests) {
    try {
      await test.fn();
      console.log(`    ✓ ${test.name}`);
      passed++;
    } catch (err: any) {
      console.log(`    ✗ ${test.name}`);
      console.log(`      ${err.message}`);
      failed++;
    }
  }

  console.log(`\n  Results: ${passed} passed, ${failed} failed, ${passed + failed} total\n`);

  if (failed > 0) {
    throw new Error(`${failed} test(s) failed`);
  }
}

runTests();
