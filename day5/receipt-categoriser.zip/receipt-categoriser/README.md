### Receipt Categoriser

AI-driven receipt categorisation module for GreenChit. Reads receipt images via OCR, suggests an expense category using Azure OpenAI, and falls back to rule-based keyword matching when the LLM is unavailable.

## Run the tests

`` 
cd receipt-categoriser
npm install
npx ts-node tests/acceptance.test.ts
 
``