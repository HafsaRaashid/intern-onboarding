// src/categoriser.ts
// Main entry point for the Receipt Categoriser.
// Orchestrates: feature flag check → input validation → OCR → LLM → fallback.

import { classifyWithRules } from "./rule-based-categoriser";

// ── Types (from spec contract) ──

export type Category = "Meals" | "Travel" | "Lodging" | "Office Supplies" | "Other";
export type Source = "llm" | "rule-based" | "default";

export interface CategoriserInput {
  claim_id: string;
  receipt_image_url: string;
}

export interface CategoriserResult {
  claim_id: string;
  category: Category;
  confidence: number;
  needs_review: boolean;
  source: Source;
}

export interface CategoriserError {
  code: number;
  error: string;
  detail?: string;
  max_bytes?: number;
}

// ── Dependency interfaces (injectable for testing) ──

export interface OcrClient {
  extractText(imageUrl: string): Promise<string>;
}

export interface LlmClient {
  classify(text: string): Promise<{ category: Category; confidence: number }>;
}

export interface FeatureFlagClient {
  isEnabled(flagName: string): Promise<boolean>;
}

export interface TelemetryClient {
  trackEvent(name: string, properties: Record<string, string | number | boolean>): void;
}

export interface ImageMetadataClient {
  getImageSize(imageUrl: string): Promise<number>;
  getImageFormat(imageUrl: string): Promise<string>;
}

export interface ClaimRepository {
  exists(claimId: string): Promise<boolean>;
}

export interface CategoriserDeps {
  ocr: OcrClient;
  llm: LlmClient;
  featureFlag: FeatureFlagClient;
  telemetry: TelemetryClient;
  imageMetadata: ImageMetadataClient;
  claims: ClaimRepository;
}

// ── Constants ──

const CONFIDENCE_THRESHOLD = 0.6;
const MAX_IMAGE_BYTES = 10 * 1024 * 1024; // 10 MB
const VALID_FORMATS = ["jpeg", "jpg", "png"];
const FEATURE_FLAG_NAME = "receipt-categoriser";

// ── Main function ──

export async function categoriseReceipt(
  input: CategoriserInput,
  deps: CategoriserDeps
): Promise<CategoriserResult | CategoriserError> {
  const startTime = Date.now();

  // 1. Check feature flag
  const isEnabled = await deps.featureFlag.isEnabled(FEATURE_FLAG_NAME);
  if (!isEnabled) {
    return null as unknown as CategoriserResult;
  }

  // 2. Validate input
  if (!input.claim_id || !input.receipt_image_url) {
    return {
      code: 400,
      error: "Invalid input",
      detail: "claim_id and receipt_image_url are required",
    };
  }

  // 3. Check image format
  const format = await deps.imageMetadata.getImageFormat(input.receipt_image_url);
  if (!VALID_FORMATS.includes(format.toLowerCase())) {
    return {
      code: 400,
      error: "Invalid input",
      detail: `Unsupported image format: ${format}. Accepted: jpeg, png`,
    };
  }

  // 4. Check image size
  const sizeBytes = await deps.imageMetadata.getImageSize(input.receipt_image_url);
  if (sizeBytes > MAX_IMAGE_BYTES) {
    return {
      code: 413,
      error: "File too large",
      max_bytes: MAX_IMAGE_BYTES,
    };
  }

  // 5. Check claim exists
  const claimExists = await deps.claims.exists(input.claim_id);
  if (!claimExists) {
    return {
      code: 404,
      error: "Claim not found",
    };
  }

  // 6. Run OCR
  let ocrText: string;
  try {
    ocrText = await deps.ocr.extractText(input.receipt_image_url);

    if (!ocrText || ocrText.trim().length === 0) {
      throw new Error("OCR returned empty text");
    }
  } catch {
    // OCR failed — return default per FR4
    const result: CategoriserResult = {
      claim_id: input.claim_id,
      category: "Other",
      confidence: 0.0,
      needs_review: true,
      source: "default",
    };
    emitTelemetry(deps.telemetry, result, Date.now() - startTime);
    return result;
  }

  // 7. Run LLM, fall back to rule-based if it fails
  let category: Category;
  let confidence: number;
  let source: Source;

  try {
    const llmResult = await deps.llm.classify(ocrText);

    category = llmResult.category;
    confidence = llmResult.confidence;
    source = "llm";
  } catch {
    // LLM failed — fall back to rule-based per NFR
    const ruleResult = classifyWithRules(ocrText);
    category = ruleResult.category;
    confidence = ruleResult.confidence;
    source = "rule-based";
  }

  // 8. Determine needs_review flag (spec: below 0.6)
  const needs_review = confidence < CONFIDENCE_THRESHOLD;

  const result: CategoriserResult = {
    claim_id: input.claim_id,
    category,
    confidence,
    needs_review,
    source,
  };

  // 9. Emit telemetry
  emitTelemetry(deps.telemetry, result, Date.now() - startTime);

  return result;
}

// ── Helpers ──

function emitTelemetry(
  telemetry: TelemetryClient,
  result: CategoriserResult,
  latencyMs: number
): void {
  telemetry.trackEvent("categoriser.suggested", {
    claim_id: result.claim_id,
    category: result.category,
    confidence: result.confidence,
    needs_review: result.needs_review,
    source: result.source,
    latency_ms: latencyMs,
  });
}