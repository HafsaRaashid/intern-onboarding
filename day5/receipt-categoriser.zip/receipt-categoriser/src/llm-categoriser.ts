// src/llm-categoriser.ts
// Calls Azure OpenAI (gpt-4.1) to classify receipt text into a category.
// This module is only called when the feature flag is on and OCR succeeded.

import type { Category } from "./categoriser";

export interface LlmClassifyResult {
  category: Category;
  confidence: number;
}

const VALID_CATEGORIES: Category[] = [
  "Meals",
  "Travel",
  "Lodging",
  "Office Supplies",
  "Other",
];

const SYSTEM_PROMPT = `You are a receipt classifier for an internal expense reimbursement system.
Given the text extracted from a receipt, classify it into exactly one of these categories:
- Meals (restaurants, cafes, food purchases)
- Travel (taxis, rideshare, flights, fuel, transport)
- Lodging (hotels, accommodation, room charges)
- Office Supplies (stationery, paper, printer supplies, desk items)
- Other (does not fit any category above)

Respond in JSON only, no other text:
{ "category": "<one of the five categories>", "confidence": <0.0 to 1.0> }

Rules:
- confidence reflects how clearly the receipt fits the category
- If the receipt has mixed items from different categories, pick the best fit and lower the confidence
- If nothing fits, use "Other"`;

/**
 * Calls Azure OpenAI to classify receipt text.
 * In production, this calls the Azure OpenAI REST API.
 * For testing, the LlmClient dependency in categoriser.ts is mocked.
 *
 * This function is exported for direct use when the caller manages
 * its own Azure OpenAI client instance.
 */
export function buildLlmPrompt(ocrText: string): { system: string; user: string } {
  return {
    system: SYSTEM_PROMPT,
    user: `Classify this receipt:\n\n${ocrText}`,
  };
}

/**
 * Parses the raw LLM response string into a typed result.
 * Validates that the category is one of the allowed values.
 * Clamps confidence to 0.0–1.0 range.
 */
export function parseLlmResponse(raw: string): LlmClassifyResult {
  let parsed: { category: string; confidence: number };

  try {
    // Strip markdown fences if the LLM wraps in ```json ... ```
    const cleaned = raw.replace(/```json\s*/g, "").replace(/```/g, "").trim();
    parsed = JSON.parse(cleaned);
  } catch {
    throw new Error(`Failed to parse LLM response: ${raw}`);
  }

  if (!parsed.category || typeof parsed.confidence !== "number") {
    throw new Error(`Invalid LLM response shape: ${raw}`);
  }

  // Validate category is one of the allowed values
  const category = VALID_CATEGORIES.find(
    (c) => c.toLowerCase() === parsed.category.toLowerCase()
  );

  if (!category) {
    throw new Error(`LLM returned unknown category: ${parsed.category}`);
  }

  // Clamp confidence to valid range
  const confidence = Math.max(0, Math.min(1, parsed.confidence));

  return { category, confidence };
}
