// src/rule-based-categoriser.ts
// Keyword-based fallback categoriser. Used when Azure OpenAI is unavailable.
// Keywords are placeholders — the BA team / Finance should define the final list.
// Confidence is calculated based on number of keyword matches:
//   - 1 match = 0.5
//   - 2+ matches = 0.7

import type { Category } from "./categoriser";

export interface RuleBasedResult {
  category: Category;
  confidence: number;
}

interface KeywordRule {
  category: Category;
  keywords: string[];
}

const RULES: KeywordRule[] = [
  {
    category: "Meals",
    keywords: [
      "restaurant",
      "cafe",
      "food",
      "lunch",
      "dinner",
      "breakfast",
      "pizza",
      "rice",
      "curry",
      "meal",
      "dining",
      "eat",
      "bistro",
      "takeaway",
      "coffee",
    ],
  },
  {
    category: "Travel",
    keywords: [
      "uber",
      "pickme",
      "taxi",
      "cab",
      "airport",
      "bus",
      "train",
      "fuel",
      "petrol",
      "flight",
      "airline",
      "fare",
      "ride",
      "transport",
      "toll",
    ],
  },
  {
    category: "Lodging",
    keywords: [
      "hotel",
      "inn",
      "room",
      "nights",
      "accommodation",
      "stay",
      "booking",
      "resort",
      "lodge",
      "hostel",
      "check-in",
      "checkout",
    ],
  },
  {
    category: "Office Supplies",
    keywords: [
      "paper",
      "pen",
      "ink",
      "toner",
      "printer",
      "stapler",
      "envelope",
      "folder",
      "stationery",
      "notebook",
      "desk",
      "lamp",
      "cartridge",
      "marker",
    ],
  },
];

/**
 * Classifies receipt text using keyword matching.
 * Returns the category with the most keyword hits.
 * If no keywords match, returns "Other" with confidence 0.0.
 */
export function classifyWithRules(ocrText: string): RuleBasedResult {
  const textLower = ocrText.toLowerCase();

  let bestCategory: Category = "Other";
  let bestMatchCount = 0;

  for (const rule of RULES) {
    const matchCount = rule.keywords.filter((kw) =>
      textLower.includes(kw)
    ).length;

    if (matchCount > bestMatchCount) {
      bestMatchCount = matchCount;
      bestCategory = rule.category;
    }
  }

  // No matches — return Other
  if (bestMatchCount === 0) {
    return { category: "Other", confidence: 0.0 };
  }

  // Confidence: 1 match = 0.5, 2+ matches = 0.7
  const confidence = bestMatchCount >= 2 ? 0.7 : 0.5;

  return { category: bestCategory, confidence };
}
