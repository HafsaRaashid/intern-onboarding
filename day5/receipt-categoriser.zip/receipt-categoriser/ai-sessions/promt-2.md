Prompt 2 — Remove timeout mechanism

The code adds a 4-second  timeout with a rejectAfter helper that forces fallback to rule-based if the LLM call exceeds the remaining time budget.
The spec says "under 4 seconds p95 from upload to displayed suggestion" that is a measurement requirement, not a hard timeout.
Remove all behaviour related to timeout.
Do not change any other behaviour.