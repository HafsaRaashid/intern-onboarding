Implement a Receipt Categorizer module in TypeScript. Below is the complete specification and acceptance criteria attached. Implement the feature so that all acceptance criteria can be made to pass with a small test runner. 
Contract:

* Before writing code, list any ambiguities in the spec that you want clarified
* Do not invent fields, types or endpoints not present in spec
* Structure required: `src/categoriser.ts` — main entry point ,src/llm-categoriser.ts— calls Azure OpenAI, returns category + confidence, `src/rule-based-categoriser.ts` — keyword-based fallback when LLM is unavailable
* Also validate and generate `tests/acceptance.test.ts based on the `Acceptance criteria attached
* Do not create any other files