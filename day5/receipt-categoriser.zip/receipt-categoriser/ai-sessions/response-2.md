# Response 2 — Timeout removed

## Changes made

Removed four things from `src/categoriser.ts`:

**1. Constant removed:**
```typescript
// Before
const TOTAL_TIMEOUT_MS = 4000;
// After — deleted entirely
```

**2. Timeout calculation removed:**
```typescript
// Before
const remainingMs = TOTAL_TIMEOUT_MS - (Date.now() - startTime);
// After — deleted entirely
```

**3. LLM call simplified:**
```typescript
// Before
try {
  if (remainingMs <= 0) {
    throw new Error("Timeout — no time left for LLM");
  }
  const llmResult = await Promise.race([
    deps.llm.classify(ocrText),
    rejectAfter(remainingMs),
  ]);
  category = llmResult.category;
  confidence = llmResult.confidence;
  source = "llm";
} catch {
  const ruleResult = classifyWithRules(ocrText);
  category = ruleResult.category;
  confidence = ruleResult.confidence;
  source = "rule-based";
}

// After
try {
  const llmResult = await deps.llm.classify(ocrText);
  category = llmResult.category;
  confidence = llmResult.confidence;
  source = "llm";
} catch {
  const ruleResult = classifyWithRules(ocrText);
  category = ruleResult.category;
  confidence = ruleResult.confidence;
  source = "rule-based";
}
```

**4. Helper function removed:**
```typescript
// Before
function rejectAfter(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error(`Timeout after ${ms}ms`)), ms);
  });
}
// After — deleted entirely
```

## Result

All 10 tests still pass:

```
  AC-01: Happy path — clear meal receipt
  AC-03: LLM unavailable — fallback to rule-based
  AC-04: OCR failure — unreadable image
  AC-05: Oversized payload
  AC-07: Feature flag off
    ✓ returns Meals category with confidence >= 0.6 and source llm
    ✓ emits Application Insights categoriser.suggested event
    ✓ returns source rule-based when LLM throws a 503
    ✓ does not expose LLM failure to the user
    ✓ returns Other with confidence 0.0 and source default
    ✓ returns Other when OCR returns empty text
    ✓ returns 413 when image exceeds 10 MB
    ✓ does not call OCR or LLM when image is too large
    ✓ returns null when feature flag is off
    ✓ does not call OCR or LLM when feature flag is off

  Results: 10 passed, 0 failed, 10 total
```
