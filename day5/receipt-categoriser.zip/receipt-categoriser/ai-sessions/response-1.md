**Ambiguities found in the spec before coding:**

**1. Timeout split**
Spec says 4 seconds p95 total. OCR and LLM are two separate calls. How to split? I'll default to **2s OCR + 2s LLM** unless you say otherwise.

**2. Rule-based keywords**
Open question in section 7. For implementation, I'll use a reasonable placeholder set (hotel→Lodging, restaurant→Meals, etc.) that can be swapped later.

**3. Rule-based confidence**
Open question in section 7. Example 4 in the spec shows rule-based returning `confidence: 0.7`. I'll calculate based on number of keywords matched — single match = 0.5, multiple matches = 0.7.

**4. needs_review boundary**
Spec says "below 0.6." I'll treat that as `confidence < 0.6` (exactly 0.6 does NOT trigger the flag).

**5. Application Insights event timing**
The event includes `outcome: "accepted" | "overridden"` which only exists after the user responds. The categoriser can't know this at suggestion time. I'll split it: the categoriser returns the suggestion, and a separate `logOutcome()` function emits the event when the user accepts or overrides.

**6. Feature flag off — return type**
Spec doesn't say. I'll return `null` so the caller knows to skip and show the manual dropdown.

**7. Image input**
Contract says `receipt_image_url`. I'll accept the URL and fetch it internally rather than expecting raw bytes.

---

If these defaults are fine, say **"go"** and I'll generate the four files.