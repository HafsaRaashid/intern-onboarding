# ADR 0001: Record architecture decisions

## Status
Accepted (date: 2026-05-29)

## Context
GreenChits design pack will be handed off to a development team for implementation. Design decisions made now will shape the project for years, but the reasoning behind those decisions is easily lost during handoff. Without a written record, the development team will either repeat past debates or blindly accept choices they don't understand.

## Decision
We use Architecture Decision Records (ADRs) following the Nygard template. Each ADR is a short markdown file stored in the `adrs/` folder of the design repository. ADRs are numbered sequentially and once accepted, they are never deleted — only superseded by a newer ADR that references the old one.

## Consequences
- **Easier:** The development team can read the ADR folder and understand why the system is shaped the way it is without chasing down the original designers.
- **Harder:** Every significant decision requires writing an ADR during the design phase, which adds time to sessions.
- **Different:** The design pack becomes self-documenting. Reviewers and developers judge decisions against written reasoning, not verbal explanations.

## Alternatives considered
- **Wiki pages** — rejected because wikis get edited over time and lose the original reasoning. ADRs are immutable once accepted.
- **No formal record** — rejected because undocumented decisions lead to repeated debates and inconsistent architecture during implementation.
