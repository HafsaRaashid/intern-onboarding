# ADR 0003: Database — Azure SQL over Cosmos DB

## Status
Accepted (date: 2026-05-29)

## Context
GreenChit needs a database for claims, state transitions, user-role mappings, and a tamper-evident audit log retained for 7 years. The data is naturally relational — a claim has line items, each transition links to a user and a claim, and role-based access depends on foreign key relationships between users, teams, and claims. The audit log requires strong consistency: every state change must be recorded exactly once with no eventual-consistency surprises. The brief constrains us to Azure SQL or Cosmos DB.

## Decision
We choose Azure SQL as the single database for all GreenChit data. Row-level security enforces the privacy NFR (only claimant, manager, finance, and audit roles can view a given claim). The audit table uses database-level permissions to block UPDATE and DELETE, ensuring append-only tamper-evident logging.

## Consequences
- **Easier:** The data model maps naturally to relational tables with foreign keys. SQL is widely understood — the development team can query, debug, and report on data without learning a new paradigm. Row-level security is built in and well documented.
- **Harder:** Azure SQL scales vertically, not horizontally. If GreenChit's usage ever grows far beyond BISTEC's current staff size, the database tier must be manually upgraded. This is unlikely given the internal-only scope but worth noting.
- **Different:** Schema changes require migrations. With Azure SQL, adding a new field to a claim means writing a migration script. 

## Alternatives considered
- **Cosmos DB** — globally distributed NoSQL with automatic horizontal scaling. Rejected because GreenChit's data is relational, the scale is small (internal tool, ~100 staff), and Cosmos DB's eventual consistency model conflicts with the audit log's strong consistency requirement. Its RU-based pricing is also harder to predict for a team unfamiliar with the model.
