# ADR 0002: Hosting platform — Azure App Service

## Status
Accepted (date: 2026-05-29)

## Context
GreenChit must be hosted on Azure. The two options are Azure App Service and Azure Container Apps. The system has an API service and a Service Bus consumer that delivers notifications. GreenChit is an internal tool serving ~100 BISTEC staff — traffic is low, deployments will be infrequent, and the development team is small. The NFR requires 99.9% availability during business hours (08:00–19:00 SLST, Mon–Fri). The trade-off table (see `Hafsa-day4-trade-offs-and-review.md`) scores App Service 21 vs Container Apps 20.

## Decision
We choose Azure App Service (Basic tier, Linux) hosted in the Australia East (Sydney) region. The API runs as an ASP.NET Core application. The notification consumer runs as a BackgroundService within the same application process, reading from Azure Service Bus and posting to Teams/email. Both workloads share one App Service deployment.

## Consequences
- **Easier:** Deployment is simple — push code, it runs. No Dockerfiles, no container registry, no image build pipeline. The team focuses on features, not infrastructure. Cost is predictable at a flat monthly rate.
- **Harder:** The API and notification consumer share one process. If the notification consumer has a memory leak or unhandled exception, it could crash the API — staff would be unable to submit claims until the App Service restarts. This is a genuine risk that the development team must mitigate with proper error handling and health checks in the BackgroundService.
- **Different:** App Service runs 24/7 at a fixed cost, even though the SLA only requires business-hours availability. BISTEC pays for overnight and weekend compute that nobody uses. At Basic tier this is negligible ($13/month).

## Alternatives considered
- **Azure Container Apps** — scales to zero outside business hours and allows independent deployment of the API and notification consumer. Rejected because the operational complexity (Dockerfiles, container registry, revision management) is not justified for an internal tool with ~100 users and infrequent deployments. The cost savings from scale-to-zero do not outweigh the added complexity at this scale.
- **Azure Kubernetes Service (AKS)** — full container orchestration. Rejected because it is overkill for a simple internal tool and introduces significant operational overhead that a small team does not need.
