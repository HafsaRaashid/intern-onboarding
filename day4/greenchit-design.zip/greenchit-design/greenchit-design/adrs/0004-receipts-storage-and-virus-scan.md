# ADR 0004: Receipt storage — Blob Storage with SAS URLs and virus scanning

## Status
Accepted (date: 2026-05-29)

## Context
Staff upload up to 5 receipt images per claim, each up to 10 MB. Uploads must succeed even with intermittent connectivity on BISTEC office Wi-Fi. Routing these files through the API service would make it a bottleneck — a 10 MB upload on a shaky connection ties up an API thread for seconds. There is also a security risk: users could upload malicious files disguised as images. Since these files are stored long-term and accessed by managers and finance, an infected file could spread when downloaded.

## Decision
We choose Azure Blob Storage with short-lived SAS (Shared Access Signature) URLs for direct browser-to-blob uploads. The API generates a write-only SAS URL valid for 5 minutes. The browser uploads directly to Blob Storage, bypassing the API entirely. For virus scanning, we enable Microsoft Defender for Storage on the blob container. Defender scans each uploaded file automatically and tags it with a scan result. The API checks the scan tag before allowing the file to be attached to a submitted claim.

## Consequences
- **Easier:** Direct upload means the API never handles large binary data — it stays lightweight and responsive. Intermittent connectivity is handled by the browser retrying against Blob Storage directly, not against the API. Defender for Storage requires no custom code — it's a configuration toggle.
- **Harder:** Defender for Storage adds cost per GB scanned and introduces a scan delay (typically a few seconds) before the file is cleared. The development team must handle the gap between upload and scan completion — the UI needs to poll or wait for the scan result before confirming the upload. This is a genuine UX complication.
- **Different:** The API never sees the file content. It only generates URLs and reads scan results. This is a security benefit (reduced attack surface) but means the API cannot validate image content (dimensions, format) server-side — that validation must happen client-side or via a post-upload Azure Function.

## Alternatives considered
- **Upload through the API** — the API receives the file and forwards it to Blob Storage. Rejected because it makes the API a bottleneck for large uploads, increases memory usage, and fails the intermittent connectivity requirement. A dropped connection mid-upload wastes the entire transfer.
- **No virus scanning** — rely on the browser and OS-level antivirus. Rejected because not all staff devices are guaranteed to have up-to-date antivirus, and a single infected file accessed by finance could compromise a privileged workstation. The 7-year audit retention policy means infected files would persist for years if not caught at upload.
- **Custom virus scan via ClamAV in a container** — run an open-source scanner as a sidecar. Rejected because it adds operational overhead (keeping virus definitions updated, scaling the scanner) that Defender for Storage handles as a managed service.
